#helper
ifelse2 <-function(cond,a,b){
  if(cond == TRUE) return(a)
  return(b)
}
my_AICc <- function(mod_obj){
  p <- mod_obj$df.null - mod_obj$df.residual + 1
  ans <- AIC(mod_obj) + (2*p^2 + 2*p) / (nrow(mod_obj$model) - p -1)
  return(ans)
}
my_finder <- function(flag,cur_mod,criteria,alpha){
  ret <- rep(0,2)
  ret[1] <- tail(predict(cur_mod$om,type="response"),1)
  ret[2] <- criteria(cur_mod$om)
  if(flag){
    ret[1]<- ifelse2(tail(!cur_mod$linearity,1),inference(cur_mod,alpha,prediction = TRUE)[,2],ret[1])
    ret[2]<- ifelse2(tail(!cur_mod$linearity,1),criteria(cur_mod$lcm),criteria(cur_mod$om))
  }
  return(ret)
}

#' Exponential Family Generalized Linear Models Done Right
#' 
#' Provide the prediction as a one-sided confidence intervals given new data.
#' Not appropriate when the MLE exists in the original model.
#' @export predict
#' @param object a fitted object of class \code{glmdr}.
#' @param newdata An optional data frame having predictors. If omitted, the fitted predictors are used.
#' @param crit Information Criteria, can be one of "AIC", "BIC", or "AICc."
#' @param alpha the confidence level. The default is set to \code{alpha = 0.05}.
#' @param interval eight different methods to obtain a confidence interval. Default is a Wilson interval. See also \link[binom]{binom.confint}
#' @return A dataframe that includes (1 - alpha) times 100 percent confidence intervals for mean-value parameters for new data points.
#' @usage predict(object, newdata = new_df, cirt="AICc")
#' @import binom
#' @export
#' @examples 
#'\dontrun{
#'mod <- glmdr(y~x, family="binomial")
#'predict(mod, newdata = new_df, cirt="AICc")
#'}
predict.glmdr <- function(object, newdata = NULL, crit="BIC",alpha=0.05, interval="wilson"){
  
  if(is.null(newdata)){
      return(ifelse(predict(object$om,type="response")>=0.5,1,0))
  }
  #selecting criteria
  criteria <- BIC
  if(crit=="AIC"){
    criteria <- AIC
  }
  if(crit=="AICc"){
    criteria <- my_AICc
  }
  ret_mat <- matrix(NA,ncol=2,nrow=nrow(newdata))
  stopifnot((ncol(newdata)+1)==ncol(object$om$model))

  for(i in 1:nrow(newdata)){
    new_0 <- new_0 <- y_idx <- NULL
    if(ncol(newdata)==1){
      new_0 <- cbind(0,newdata)
      new_1 <- cbind(0,newdata)
      colnames(new_0) <- colnames(new_1) <- names(object$om$model)
      new_0 <- rbind(object$om$model,new_0)
      new_1 <- rbind(object$om$model,new_1)
    }
    else{
      #generate data
      new_0 <- data.frame(0, newdata[i,,drop=FALSE])
      new_1 <- data.frame(1, newdata[i,,drop=FALSE])
      names(new_0)[1] <- names(new_1)[1] <- paste(formula(object$om))[2]
      y_idx <- which(names(glmdr_mod$om$model) == paste(formula(glmdr_mod$om))[2])
      names(new_0)[2:ncol(new_0)] <- names(new_1)[2:ncol(new_1)] <- colnames(object$om$model)[-y_idx]
      new_0 <- rbind(object$om$model,new_0)
      new_1 <- rbind(object$om$model,new_1)
      rownames(new_0)[nrow(new_0)] <- rownames(new_1)[nrow(new_1)] <- (max(as.numeric((row.names(object$om$x))))+1)
    }
    #1. Pick new x and fit models with y=0 and y=1 separately.
    glmdr_mod_y0 <- glmdr(formula(object$om),data=new_0,family="binomial")
    glmdr_mod_y1 <- glmdr(formula(object$om),data=new_1,family="binomial")
    y0_glmdr_flag <- ifelse2(is.null(glmdr_mod_y0$lcm),FALSE,TRUE) #If flag = FALSE, use om
    y1_glmdr_flag <- ifelse2(is.null(glmdr_mod_y1$lcm),FALSE,TRUE)
    ret_y0 <- my_finder(flag=y0_glmdr_flag,cur_mod=glmdr_mod_y0,criteria,alpha=alpha)
    ret_y1 <- my_finder(flag=y1_glmdr_flag,cur_mod=glmdr_mod_y1,criteria,alpha=alpha)
    phat_y0 <- ret_y0[1]
    phat_y1 <- ret_y1[1]
    #3. Obtain IC values for each model (IC is shorthand for information criterion, examples include BIC, AIC, AICc).
    criteria_y0 <- ret_y0[2]
    criteria_y1 <- ret_y1[2]
    #4. Model average the phat values using model weights wj = exp(-IC_j/2) / sum( exp(-IC_j / 2) ) so that phat* = sum wj phat_j
    criteria_y0 <- exp(-criteria_y0/2)
    criteria_y1 <- exp(-criteria_y1/2)
    w0 <- criteria_y0/(criteria_y0+criteria_y1)
    w1 <- criteria_y1/(criteria_y0+criteria_y1)
    if(criteria_y0 == criteria_y1){
      w0 <- w1 <- 0.5
    }
    phat_star <- w0 * phat_y0 + w1 * phat_y1
    #5. construct CIs with respect to phat*
    n <- nrow(new_0)
    ret_mat[i,] <- as.matrix(binom.confint(x=phat_star,1,conf.level =(1-alpha),methods=interval)[5:6])
  }
  
  colnames(ret_mat) <- c("lower","upper")
  rownames(ret_mat) <- 1:nrow(ret_mat)
  return(ret_mat)
}